import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        LocalDate date = LocalDate.of(1975, 1, 28);

        System.out.println(date.getDayOfMonth());
        System.out.println(date.getYear());


        LocalDate[] dates = {
                LocalDate.of(1975, 1, 28),
                LocalDate.of(1971, 1, 16),
                LocalDate.of(1995, 12, 15),
                LocalDate.of(2018, 11, 24),
                LocalDate.of(1994, 1, 7),
                LocalDate.of(2021, 8, 8),
                LocalDate.of(2022, 5, 1),
                LocalDate.of(2023, 8, 21),
        };
        System.out.println(dates);
        sortByYear(dates);
        System.out.println(dates);
        sortByDay(dates);
        System.out.println(dates);
    }

    public static void sortByYear(LocalDate[] sortArr) {
        for (int i = 0; i < sortArr.length - 1; i++) {
            for (int j = 0; j < sortArr.length - i - 1; j++) {
                if (sortArr[j + 1].getYear() < sortArr[j].getYear()) {
                    LocalDate swap = sortArr[j];
                    sortArr[j] = sortArr[j + 1];
                    sortArr[j + 1] = swap;
                }
            }
        }

    }
    public static void sortByDay(LocalDate[] sortArr) {
        for (int i = 0; i < sortArr.length - 1; i++) {
            for (int j = 0; j < sortArr.length - i - 1; j++) {
                if (sortArr[j + 1].getDayOfMonth() < sortArr[j].getDayOfMonth()) {
                    LocalDate swap = sortArr[j];
                    sortArr[j] = sortArr[j + 1];
                    sortArr[j + 1] = swap;
                }
            }
        }

    }
}
